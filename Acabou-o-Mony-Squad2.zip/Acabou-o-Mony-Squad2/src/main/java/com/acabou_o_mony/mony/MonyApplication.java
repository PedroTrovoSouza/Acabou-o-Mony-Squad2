package com.acabou_o_mony.mony;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MonyApplication {
	public static void main(String[] args) {
		SpringApplication.run(MonyApplication.class, args);
	}
}
