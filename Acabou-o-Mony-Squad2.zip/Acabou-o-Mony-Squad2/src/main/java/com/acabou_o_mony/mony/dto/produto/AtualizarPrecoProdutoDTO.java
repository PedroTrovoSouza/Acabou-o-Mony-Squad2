package com.acabou_o_mony.mony.dto.produto;

public record AtualizarPrecoProdutoDTO(double preco) {
}
