package com.acabou_o_mony.mony.enums;

public enum Genero {
    MASCULINO,
    FEMININO,
    PREFIRO_NAO_INFORMAR
}
