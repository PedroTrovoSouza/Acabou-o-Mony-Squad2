package com.acabou_o_mony.mony.enums;

public enum StatusPedido {
    EM_ANDAMENTO,
    FINALIZADO
}
