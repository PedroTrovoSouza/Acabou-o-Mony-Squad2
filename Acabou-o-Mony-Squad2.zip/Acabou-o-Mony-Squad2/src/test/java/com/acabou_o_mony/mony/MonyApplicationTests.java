package com.acabou_o_mony.mony;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MonyApplicationTests {

	@Test
	void contextLoads() {
	}

}
